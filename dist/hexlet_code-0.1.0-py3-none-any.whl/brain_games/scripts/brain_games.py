#!/usr/bin/env python3
import brain_games.cli as cli


def main(game):
    print("Welcome to the Brain Games!")
    name = cli.welcome_user()
    results = game()
    print_result(results, name)


def print_result(results: dict, name: str):
    if results['is_not_lose']:
        print(f"Congratulations, {name}!")
    else:
        ans, cor_ans = results['player_answer'], results['correct_answer']
        print(f"'{ans}' is wrong answer ;(. Correct answer was '{cor_ans}'.")
        print(f"Let's try again, {name}!")


if __name__ == "__main__":
    main()
