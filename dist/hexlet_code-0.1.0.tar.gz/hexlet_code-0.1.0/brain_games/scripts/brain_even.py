#!/usr/bin/env python3
import prompt
from random import randint
from brain_games.scripts.brain_games import main as game_core


def main():
    game_core(game())


def game(games_count: int = 3) -> dict:
    print('Answer "yes" if the number is even, otherwise answer "no".')
    is_not_lose = True
    game_results = {
        'is_not_lose': is_not_lose,
        'player_answer': None,
        'correct_answer': None,
    }
    while games_count != 0 and is_not_lose:
        num = randint(1, 100)
        print(f'Question: {num}')
        answer = prompt.string('Your answer: ').lower()
        correct_answer = is_even(num)
        is_not_lose = check_answer(answer, correct_answer)
        if is_not_lose:
            print('Correct!')
            games_count -= 1
    if not is_not_lose:
        game_results['player_answer'] = answer
        game_results['correct_answer'] = correct_answer
        return game_results
    return game_results


def check_answer(user_answer: str, correct_answer: str) -> bool:
    return user_answer == correct_answer


def is_even(num: int) -> str:
    if num % 2 == 0:
        return 'yes'
    return 'no'


if __name__ == '__main__':
    main()
