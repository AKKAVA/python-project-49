### Hexlet tests and linter status:
[![Actions Status](https://github.com/AKKAVA/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AKKAVA/python-project-49/actions)

### Code Climate Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/4e1901eeaa42d2fce58c/maintainability)](https://codeclimate.com/github/AKKAVA/python-project-49/maintainability)

### Asciinema record:
[![asciicast](https://asciinema.org/a/SSvQozIXl9Zi4f0wHBHvGhK63.svg)](https://asciinema.org/a/SSvQozIXl9Zi4f0wHBHvGhK63)